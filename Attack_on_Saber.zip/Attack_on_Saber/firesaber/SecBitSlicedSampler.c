#include <string.h>
#include <stdint.h>
#include <math.h>
#include "api.h"
#include "SABER_params.h"
#include "SecAnd.h"

void SecBitSlicedSampler(uint16_t x[u][32],uint16_t y[u][32],uint16_t A[u][32][SABER_N]){
    uint16_t x1[SABER_N];
    uint16_t y1[SABER_N];
    uint16_t z1[SABER_N];
    uint16_t z[u][32];

    pack(x,*x1);
    pack(y,*y1);

    SecBitAdd(x1,z1);
    SecBitAdd(z1,y1,z1);
    SecConstAdd(z1,z1);
    unpack(z1,*z);
    for(int a=0;a<u;a++){
        for(int i=0;i<32;i++){
            for(int j=0;j<SABER_N;j++){
                A[u][i][j]=pre_B2A(z[i]);
            }
        }
    }
    
}