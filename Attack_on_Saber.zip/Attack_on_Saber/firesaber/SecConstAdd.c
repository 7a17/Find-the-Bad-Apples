#include <string.h>
#include <stdint.h>
#include <math.h>
#include "api.h"
#include "SABER_params.h"
#include "SecAnd.h"

//for u=4
void SecConstAdd(uint16_t x[u][SABER_N],unsigned *y){
    int i,j;
    for(i=0;i<u;i++){
        for(j=0;j<SABER_N;j++){
            y[i][j]=x[i][j];
        }
    }
    for(i=0;i<SABER_N;i++){
        y[2][i]=y[2][i]^y[1][i];
    }
    y[1][0]=y[1][0]^1;
}