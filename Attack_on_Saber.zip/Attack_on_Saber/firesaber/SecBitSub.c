#include <string.h>
#include <stdint.h>
#include <math.h>
#include "api.h"
#include "SABER_params.h"
#include "SecAnd.h"
const int n;

void SecBitSub(unsigned *x,unsigned *z){
    uint16_t t[SABER_N],w[n],z1[n];
    int k;
    int i,j,a,b;
    for(i=0;i<SABER_N;i++){ 
        t[i]=0;
        z[i]=0;
    }
    for(j=0;j<k;j++){
        for(i=0;i<n;i++){
            t[i*n]=z[i*n]^x[j];
            w[i]=x[j+i*n];
        }
        for(int l=1;l<(floor(log2(j))+1);l++){
            for(i=0;i<n;i++){
                z1[j]=z[l-1+i*n];
            }
            SecAnd(w,z1,z1);
            for(i=0;i<n;i++){
                t[l+i*n]=z[l+i*n]^w[j];
            }
        }
        for(i=0;i<SABER_N;i++){
            z[i]=t[i];
        }
    }
}

/*
void SecBitSub(uint16_t z[u][SABER_N],uint16_t y[u][SABER_N]){
    uint16_t t[u][SABER_N],w[SABER_N];
    uint16_t w1[SABER_N];
    uint16_t U[SABER_N];
    int i,j,a,b;
    for(i=0;i<u;i++){
        for(j=0;j<SABER_N;j++){
            t[i][j]=0;
        }
    }
    for(i=0;i<u;i++){
        for(j=0;j<SABER_N;j++){
            t[0][j]=z[0][j]^y[i][j];
        }
        for(j=0;j<SABER_N;j++){
            w[j]=y[i][j];
        }
        for(int l=1;l<(floor(log2(j))+1);l++){
            for(i=0;i<SABER_N;i++){
                U[i]=z[l-1][i];
            }
            U[0]=!U[0];
            SecAnd(w,U,w1);
            for(i=0;i<SABER_N;i++){
                t[l][i]=z[l][l]^w[i];
            }
        }
        for(a=0;a<u;a++){
            for(b=0;b<SABER_N;b++){
                z[a][b]=t[a][b];
            }
        }
    }
}
*/  
