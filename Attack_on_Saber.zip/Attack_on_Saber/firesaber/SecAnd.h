#ifndef SECAND_H
#define SECAND_H

#include "SABER_params.h"

void SecAnd(uint16_t x[SABER_N],uint16_t y[SABER_N],uint16_t z[SABER_N])