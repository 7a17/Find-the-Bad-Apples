#include <string.h>
#include <stdint.h>
#include <math.h>
#include "api.h"
#include "SABER_params.h"
#include "SecAnd.h"

void SecBitAdd(unsigned *x,unsigned *z){
    int n;
    uint16_t s[SABER_N],cin[n],z1[n];
    int i,j;
    for(i=0;i<SABER_N;i++){
        z[i]=0;
    }
    for(j=0;j<u;j++){
        for(i=0;i<n;i++){
            cin[j]=x[j+i*n];
        }
        for(i=0;i<n;j++){
            s[0]=z[j+i*n]^cin[j];
        }
        for(int l=1;l<(floor(log2(j))+1);l++){
            for(i=0;i<n;i++){
                z1[j]=z[l-1+i*n];
            }
            SecAnd(cin,z1,z1);
            for(i=0;i<n;i++){
                s[l+i*n]=z[l+i*n]^cin[j];
            }
        }
        for(i=0;i<SABER_N;i++){
            z[i]=s[i];
        }
    }
}
/*
void SecBitAdd(unsigned **x,unsigned **z){
    uint16_t s[u][SABER_N]={0};
    uint16_t cin[SABER_N];
    uint16_t z1[SABER_N];
    for(int i=0;i<u;i++){
        for(int j=0;j<SABER_N;j++){
            z[i][j]=0;
        }
    }
    int j;
    int a,b;
    for(j=0;j<u;j++)
    {
        for(int i=0;i<SABER_N;i++){
            cin[i]=x[u][i];
        }
        for(int i=0;i<SABER_N;i++){
            s[0][i]=z[0][i]^cin[i];
        }
        for(int l=1;l<(floor(log2(j))+1);l++){
            for(int i=0;i<SABER_N;i++){
                SecAnd(cin,z[l-1],z1);
                cin[i]=z1[i];
            }
            for(int i=0;i<SABER_N;i++){
                s[l][i]=z[l][i]^cin[i];
            }
        }
        for(a=0;a<u;a++){
            for(b=0;b<SABER_N;b++){
                z[a][b]=s[a][b];
            }
        }
    }
}
*/