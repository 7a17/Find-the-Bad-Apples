#include <iostream>

#define SABER_MU 6
#define SABER_ET 6
#define SABER_EQ 13
#define SABER_EP 10
#define SABER_N 256

#define h1 (1 << (SABER_EQ - SABER_EP - 1))
#define h2 ((1 << (SABER_EP - 2)) - (1 << (SABER_EP - SABER_ET - 1)) + (1 << (SABER_EQ - SABER_EP - 1)))

typedef struct _ctinfo
{
	int b1;
	int b2;
	int b3;
	int b4;
	int cm;
}ct_info;

typedef struct _attackinfo{
	int aval;
	ct_info ct1;
	int ct1_res;
	ct_info ct2;
	int ct2_res;
}attack_info;


int cof_firesaber[7] = {-3,-2,-1,0,1,2,3};

static int POS4(int a,int b,int c,int d){
	return a + b*7 + c*49 + d * 49*7;
}

attack_info gl_info[49*49];

void init_attackinfo()
{
	FILE * fp = fopen("data_firesaber.txt","r");
	if(fp == NULL){
		printf("err read file!");
		exit(0);
	}
	for(int i=0;i<49*49;i++){
		int unused;
		fscanf(fp,"%d,%d,%d,%d,%d,",&unused,&unused,&unused,&unused,&gl_info[i].aval);
		fscanf(fp,"%d,%d,%d,%d,%d,%d,",&gl_info[i].ct1.b1,&gl_info[i].ct1.b2,&gl_info[i].ct1.b3,&gl_info[i].ct1.b4,&gl_info[i].ct1.cm,&gl_info[i].ct1_res);
		fscanf(fp,"%d,%d,%d,%d,%d,%d\n",&gl_info[i].ct2.b1,&gl_info[i].ct2.b2,&gl_info[i].ct2.b3,&gl_info[i].ct2.b4,&gl_info[i].ct2.cm,&gl_info[i].ct2_res);
	}
}

int P(int a,int b,int c,int d){
	return a*7*7*7 + b*7*7 + c*7 + d;
	
}

int main(int argc, char *argv[]) {
	int aval_cnt = 0,checked_cnt = 0;
	int gen = 0;
	init_attackinfo();
	for(int r=0;r<49*49;r++){
		if(gl_info[r].aval == 0){
			int a,b,c,d;
			d = r%7;
			c = (r%49)/7;
			b = r/49%7;
			a = r/49/7;
			if(gl_info[P(a,c,b,d)].aval == 1){
				gl_info[r].aval = 1;
				gl_info[r].ct1_res = gl_info[P(a,c,b,d)].ct1_res;
				gl_info[r].ct2_res = gl_info[P(a,c,b,d)].ct2_res;
				
				gl_info[r].ct1.b1 = gl_info[P(a,c,b,d)].ct1.b1;
				gl_info[r].ct1.b2 = gl_info[P(a,c,b,d)].ct1.b3;
				gl_info[r].ct1.b3 = gl_info[P(a,c,b,d)].ct1.b2;
				gl_info[r].ct1.b4 = gl_info[P(a,c,b,d)].ct1.b4;
				gl_info[r].ct1.cm = gl_info[P(a,c,b,d)].ct1.cm;
				
				gl_info[r].ct2.b1 = gl_info[P(a,c,b,d)].ct2.b1;
				gl_info[r].ct2.b2 = gl_info[P(a,c,b,d)].ct2.b3;
				gl_info[r].ct2.b3 = gl_info[P(a,c,b,d)].ct2.b2;
				gl_info[r].ct2.b4 = gl_info[P(a,c,b,d)].ct2.b4;
				gl_info[r].ct2.cm = gl_info[P(a,c,b,d)].ct2.cm;
				gen++;
				continue;
			}else if(gl_info[P(d,b,c,a)].aval == 1){
				gl_info[r].aval = 1;
				gl_info[r].ct1_res = gl_info[P(d,b,c,a)].ct1_res;
				gl_info[r].ct2_res = gl_info[P(d,b,c,a)].ct2_res;
				gl_info[r].ct1.b1 = gl_info[P(d,b,c,a)].ct1.b4;
				gl_info[r].ct1.b2 = gl_info[P(d,b,c,a)].ct1.b2;
				gl_info[r].ct1.b3 = gl_info[P(d,b,c,a)].ct1.b3;
				gl_info[r].ct1.b4 = gl_info[P(d,b,c,a)].ct1.b1;
				gl_info[r].ct1.cm = gl_info[P(d,b,c,a)].ct1.cm;
				
				gl_info[r].ct2.b1 = gl_info[P(d,b,c,a)].ct2.b4;
				gl_info[r].ct2.b2 = gl_info[P(d,b,c,a)].ct2.b2;
				gl_info[r].ct2.b3 = gl_info[P(d,b,c,a)].ct2.b3;
				gl_info[r].ct2.b4 = gl_info[P(d,b,c,a)].ct2.b1;
				gl_info[r].ct2.cm = gl_info[P(d,b,c,a)].ct2.cm;
				gen++;
				continue;
			}else if(gl_info[P(c,b,a,d)].aval == 1){
				gl_info[r].aval = 1;
				gl_info[r].ct1_res = gl_info[P(c,b,a,d)].ct1_res;
				gl_info[r].ct2_res = gl_info[P(c,b,a,d)].ct2_res;
				gl_info[r].ct1.b1 = gl_info[P(c,b,a,d)].ct1.b3;
				gl_info[r].ct1.b2 = gl_info[P(c,b,a,d)].ct1.b2;
				gl_info[r].ct1.b3 = gl_info[P(c,b,a,d)].ct1.b1;
				gl_info[r].ct1.b4 = gl_info[P(c,b,a,d)].ct1.b4;
				gl_info[r].ct1.cm = gl_info[P(c,b,a,d)].ct1.cm;
				
				gl_info[r].ct2.b1 = gl_info[P(c,b,a,d)].ct2.b3;
				gl_info[r].ct2.b2 = gl_info[P(c,b,a,d)].ct2.b2;
				gl_info[r].ct2.b3 = gl_info[P(c,b,a,d)].ct2.b1;
				gl_info[r].ct2.b4 = gl_info[P(c,b,a,d)].ct2.b4;
				gl_info[r].ct2.cm = gl_info[P(c,b,a,d)].ct2.cm;
				gen++;
				continue;
			}else if(gl_info[P(a,d,c,b)].aval == 1){
				gl_info[r].aval = 1;
				gl_info[r].ct1_res = gl_info[P(a,d,c,b)].ct1_res;
				gl_info[r].ct2_res = gl_info[P(a,d,c,b)].ct2_res;
				gl_info[r].ct1.b1 = gl_info[P(a,d,c,b)].ct1.b1;
				gl_info[r].ct1.b2 = gl_info[P(a,d,c,b)].ct1.b4;
				gl_info[r].ct1.b3 = gl_info[P(a,d,c,b)].ct1.b3;
				gl_info[r].ct1.b4 = gl_info[P(a,d,c,b)].ct1.b2;
				gl_info[r].ct1.cm = gl_info[P(a,d,c,b)].ct1.cm;
				
				gl_info[r].ct2.b1 = gl_info[P(a,d,c,b)].ct2.b1;
				gl_info[r].ct2.b2 = gl_info[P(a,d,c,b)].ct2.b4;
				gl_info[r].ct2.b3 = gl_info[P(a,d,c,b)].ct2.b3;
				gl_info[r].ct2.b4 = gl_info[P(a,d,c,b)].ct2.b2;
				gl_info[r].ct2.cm = gl_info[P(a,d,c,b)].ct2.cm;
				gen++;
				continue;
			}
			
		}
	}
	printf("gen=%d\n",gen);
	FILE * fp = fopen("more_data_firesaber.txt","w");
	if(fp == NULL){
		printf("err read file!");
		exit(0);
	}
	
	for(int i1=0;i1<7;i1++){
		for(int i2=0;i2<7;i2++){
			for(int i3=0;i3<7;i3++){
				for(int i4=0;i4<7;i4++){
					attack_info tmp = gl_info[P(i1, i2, i3, i4)];
					printf("%d,%d,%d,%d,",i1,i2,i3,i4);
					printf("%d,",tmp.aval);
					fprintf(fp,"%d,%d,%d,%d,%d,",i1,i2,i3,i4,tmp.aval);
					printf("%d,%d,%d,%d,%d,",tmp.ct1.b1,tmp.ct1.b2,tmp.ct1.b3,tmp.ct1.b4,tmp.ct1.cm);
					printf("%d,",tmp.ct1_res);
					fprintf(fp,"%d,%d,%d,%d,%d,%d,",tmp.ct1.b1,tmp.ct1.b2,tmp.ct1.b3,tmp.ct1.b4,tmp.ct1.cm,tmp.ct1_res);
					printf("%d,%d,%d,%d,%d,",tmp.ct2.b1,tmp.ct2.b2,tmp.ct2.b3,tmp.ct2.b4,tmp.ct2.cm);
					printf("%d\n",tmp.ct2_res);
					fprintf(fp,"%d,%d,%d,%d,%d,%d\n",tmp.ct2.b1,tmp.ct2.b2,tmp.ct2.b3,tmp.ct2.b4,tmp.ct2.cm,tmp.ct2_res);
					
				}
			}
		}
	}
}

