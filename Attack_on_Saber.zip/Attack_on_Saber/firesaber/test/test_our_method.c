#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "../api.h"
#include "../poly.h"
#include "../rng.h"
#include "../SABER_indcpa.h"
#include "../verify.h"
#include "cpucycles.c"

#define SABER_MU 6
#define SABER_ET 6
#define SABER_EQ 13
#define SABER_EP 10
#define SABER_N 256
#define h1 (1 << (SABER_EQ - SABER_EP - 1))
#define h2 ((1 << (SABER_EP - 2)) - (1 << (SABER_EP - SABER_ET - 1)) + (1 << (SABER_EQ - SABER_EP - 1)))

#define MAX_ROUND 20
#define CC1 4
#define CC2 3
#define ACCURACY 960
#define EXPERIMENT_TIMES 10000

typedef struct _attackinfo{
    int aval;
	ct_4info ct1;
	int ct1_res;
	ct_4info ct2;
	int ct2_res;
}attack_info;

attack_info gl_info[49*49];
int roundarr[MAX_ROUND] = {5,9,11,13,13,17,17,17,18,21,22,22,22,22,22,22,22,22,22,22};

void init_attackinfo()
{
    FILE * fp = fopen("more_data2_firesaber.txt","r");
    if(fp == NULL)
    {
        printf("err read file!");
        exit(0);
    }
    for(int i=0;i<49*49;i++)
    {
        int unused;
        fscanf(fp,"%d,%d,%d,%d,%d,",&unused,&unused,&unused,&unused,&gl_info[i].aval);
        fscanf(fp,"%d,%d,%d,%d,%d,%d,",&gl_info[i].ct1.b1,&gl_info[i].ct1.b2,&gl_info[i].ct1.b3,&gl_info[i].ct1.b4,&gl_info[i].ct1.cm,&gl_info[i].ct1_res);
        fscanf(fp,"%d,%d,%d,%d,%d,%d\n",&gl_info[i].ct2.b1,&gl_info[i].ct2.b2,&gl_info[i].ct2.b3,&gl_info[i].ct2.b4,&gl_info[i].ct2.cm,&gl_info[i].ct2_res);
    }
}

attack_info get_attack_info(int a,int b,int c,int d)
{
    return gl_info[(d+3)+(c+3)*7+(b+3)*49+(a+3)*49*7];
}

void gene_taskinfo(int sksv_recovered[SABER_L][SABER_N], int task_list[256],int i)
{
    attack_info atk;
    for(int i=0;i<256;i++)
    {
        task_list[i] = i;
    }
	for (int i=256-1;i>=0;--i) //shuffle ...
	{
		//srand((unsigned)time(NULL));
		int rd = rand()%(i+1);
		int tmp = task_list[rd];
		task_list[rd] = task_list[i];
		task_list[i] = tmp;
	}
    for(int k=0;k<64;k++)
    {
        int a,b,c,d,res_1,res_2;
        a = sksv_recovered[i][task_list[(k%64)*4]];
        b = sksv_recovered[i][task_list[(k%64)*4+1]];
        c = sksv_recovered[i][task_list[(k%64)*4+2]];
        d = sksv_recovered[i][task_list[(k%64)*4+3]];
        atk = get_attack_info(a,b,c,d);
        if(atk.aval == 1)
        {
            continue;
        }
        else
        {
            int cir = 0;
            while(1)
            {
                //printf("k=%d,change!\n",k);
                int rd_this = k*4 + rand() % 4;
                int rd_other_block = rand() % 64;
                int rd_other = rd_other_block + rand() % 4;
                int tmp = task_list[rd_this];
                task_list[rd_this] = task_list[rd_other];
                task_list[rd_other] = tmp;

                a = sksv_recovered[i][task_list[(k%64)*4]];
                b = sksv_recovered[i][task_list[(k%64)*4+1]];
                c = sksv_recovered[i][task_list[(k%64)*4+2]];
                d = sksv_recovered[i][task_list[(k%64)*4+3]];
                atk = get_attack_info(a,b,c,d);
                if(atk.aval == 1)
                {
                    a = sksv_recovered[i][task_list[(rd_other_block%64)*4]];
                    b = sksv_recovered[i][task_list[(rd_other_block%64)*4+1]];
                    c = sksv_recovered[i][task_list[(rd_other_block%64)*4+2]];
                    d = sksv_recovered[i][task_list[(rd_other_block%64)*4+3]];
                    atk = get_attack_info(a,b,c,d);
                    if(atk.aval == 1)
                    {
                        break;
                    }
                    else
                    {
                        tmp = task_list[rd_this];
                        task_list[rd_this] = task_list[rd_other];
                        task_list[rd_other] = tmp;
                    }
                }
                else
                {
                        tmp = task_list[rd_this];
                        task_list[rd_this] = task_list[rd_other];
                        task_list[rd_other] = tmp;
                }
                cir++;
                if(cir>10000)
                    break;

            }
        }
    }
}

int getli(int round)
{
	return roundarr[round];
}

int oracle(const uint8_t ct[CRYPTO_CIPHERTEXTBYTES], const uint16_t sk[CRYPTO_SECRETKEYBYTES], const uint16_t m[SABER_KEYBYTES]) 
{

  const uint16_t m_recovered[SABER_KEYBYTES] = { 0 };
  

  indcpa_kem_dec(sk,ct,m_recovered);        // we just to decrypt the ct
  /* check msg_A given by adversary ==  the m_dec decrypted by oracle */
  for(int a = 0; a < SABER_KEYBYTES; a++) {
    if(m[a] != m_recovered[a]){
      //printf("a:%d miss:%d %d\n", a, msg_A[a], m_dec[a]);
      return 0;
    }
  }
  
  return 1;
}

int SCA_oracle(const uint8_t ct[CRYPTO_CIPHERTEXTBYTES], const uint16_t sk[CRYPTO_SECRETKEYBYTES], const uint16_t m[SABER_KEYBYTES]) 
{
    int ret = oracle(ct,sk,m);
    unsigned int rand_num;
    randombytes(&rand_num,sizeof(rand_num));
    rand_num = rand_num % 1000;
    if(rand_num < (unsigned int)(1000-ACCURACY)) //99% accuracy
        ret = (ret + 1) & 1;
    return ret;
}

static int saber_Attack(int r,int save[6]) {
    struct{
		int confidence[7];//every cof confidence
		int most_possible_cof;//0~7
		int most_confidence;
		int isok;
	} cofc[4][256];
	memset(cofc,0,sizeof(cofc));
	int already=0;

    /*pk sk ct*/
    uint8_t pk[CRYPTO_PUBLICKEYBYTES], sk[CRYPTO_SECRETKEYBYTES];
    uint8_t ct[CRYPTO_CIPHERTEXTBYTES];
	
    /* the polyvec form of true s */
	uint16_t sksv[SABER_L][SABER_N]={{0}};
    /* the polyvec to simulate the sk recovered form SCA */
    uint16_t sksv_recovered[SABER_L][SABER_N];
	int sksv1[SABER_L][SABER_N]={{0}};
    int sksv1_recovered[SABER_L][SABER_N];
	uint16_t b[SABER_L][SABER_N];
	uint16_t cm[SABER_N];

    /* the m set by adversary */
    uint8_t m[SABER_KEYBYTES]  = { 0 };
    m[0] = 0x1;         // first coeff of m is 1
	uint8_t m_recovered[SABER_KEYBYTES];
	memset(m_recovered,0,sizeof(m_recovered));

    /* get key pair */
	srand(r);
	unsigned char entropy_input[48];
	for (int i=0; i<48; i++)
        entropy_input[i] = rand()%48;
    randombytes_init(entropy_input, NULL, 256);

    if (  crypto_kem_keypair(pk, sk) != 0 ) {
        printf("crypto_kem_keypair error\n");
        return -1;
    }
	BS2POLVECq(sk, sksv);
	
	for(int i=0;i<SABER_L;i++){
		for(int j=0;j<SABER_N;j++){
			if(sksv[i][j]>3) sksv1[i][j]=sksv[i][j]-8192;
			else sksv1[i][j]=sksv[i][j];
		}
		//printf("\n\n");
	}
	
	
    int query = 0;
	memset(sksv_recovered,0,sizeof(sksv_recovered));


	for(int i = 0; i < SABER_L; i++) {
		for(int k = 0; k < SABER_N; k++) {
			memset(b,0,sizeof(b));
			int rev=0;
			if(k==0) b[i][k]=4;
			else b[i][SABER_N-k]=1024-4;
			POLVECp2BS(ct,b);
			cm[0]=16;
			POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);

			rev=SCA_oracle(ct,sk,m);
			query++;
			if(rev==1){
				if(k==0) b[i][k]=13;
				else b[i][SABER_N-k]=1024-13;
				POLVECp2BS(ct,b);
				cm[0]=15;
				POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);
				rev=SCA_oracle(ct,sk,m);
				query++;
				if(rev==0) sksv_recovered[i][k]=0;
				else{
					if(k==0) b[i][k]=12;
					else b[i][SABER_N-k]=1024-12;
					POLVECp2BS(ct,b);
					cm[0]=15;
					POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);
					rev=SCA_oracle(ct,sk,m);
					query++;
					if(rev==0) sksv_recovered[i][k]=8192-1;
					else{
						if(k==0) b[i][k]=6;
						else b[i][SABER_N-k]=1024-6;
						POLVECp2BS(ct,b);
						cm[0]=15;
						POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);
						rev=SCA_oracle(ct,sk,m);
						query++;
						if(rev==0) sksv_recovered[i][k]=8192-2;
						else sksv_recovered[i][k]=8192-3;
					}
				}
			}
			else{
				if(k==0) b[i][k]=3;
				else b[i][SABER_N-k]=1024-3;
				POLVECp2BS(ct,b);
				cm[0]=16;
				POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);
				rev=SCA_oracle(ct,sk,m);
				query++;
				if(rev==1) sksv_recovered[i][k]=1;
				else{
					if(k==0) b[i][k]=7;
					else b[i][SABER_N-k]=1024-7;
					POLVECp2BS(ct,b);
					cm[0]=17;
					POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);
					rev=SCA_oracle(ct,sk,m);
					query++;
					if(rev==1) sksv_recovered[i][k]=2;
					else sksv_recovered[i][k]=3;
				}
			}
            //printf("sksv_rec[%d][%d]=%d ",i,k,sksv_recovered[i][k]);
            if(sksv_recovered[i][k]>3) sksv1_recovered[i][k]=sksv_recovered[i][k]-8192;
			else sksv1_recovered[i][k]=sksv_recovered[i][k];
            //printf("sksv1_rec[%d][%d]=%d ",i,k,sksv1_recovered[i][k]);
            int value = sksv1_recovered[i][k]+3;
			cofc[i][k].most_possible_cof = value;
			cofc[i][k].most_confidence = 1;
			cofc[i][k].confidence[value] = 1;
		}
	}

    int checks = 0;
    for(int i = 0; i <SABER_L; i++) {
        for(int j = 0; j < SABER_N; j++) {
            if(sksv_recovered[i][j] != sksv[i][j]) {
                checks++;
                //printf("error s in s[%d][%d] \n", i, j);
            }
        }
    }

    save[0] = query;
    save[1] = checks;


    int query_check = 0;
    attack_info atk;
    int task_list[256];

    int err_cof_cnt = 0;
    int err_cof_i[1024];
    int err_cof_k[1024];
	int query_reclt = 0;
	int erral = 0;

	int confidence[4][256];
	memset(confidence,0,sizeof(confidence));
	for(int round=0;round<MAX_ROUND;round++) {
		for(int i = 0; i < SABER_L; i++) {
			gene_taskinfo(sksv1_recovered,task_list,i);

			for(int k = 0; k < SABER_N/4; k++) {
				int s1,s2,s3,s4,res_1,res_2;
				s1 = sksv1_recovered[i][task_list[k*4]];
				s2 = sksv1_recovered[i][task_list[k*4+1]];
				s3 = sksv1_recovered[i][task_list[k*4+2]];
				s4 = sksv1_recovered[i][task_list[k*4+3]];
				if(cofc[i][task_list[k*4]].isok && cofc[i][task_list[k*4+1]].isok && cofc[i][task_list[k*4+2]].isok && cofc[i][task_list[k*4+3]].isok)
					continue;
				if(cofc[i][task_list[k*4]].most_confidence > getli(round) && cofc[i][task_list[k*4+1]].most_confidence > getli(round) && cofc[i][task_list[k*4+2]].most_confidence > getli(round) && cofc[i][task_list[k*4+3]].most_confidence > getli(round))
					continue;
				atk = get_attack_info(s1,s2,s3,s4);
				// printf("debug=%d,%d,%d,%d\n",a+3,b+3,c+3,d+3);
				// printf("debug=%d,%d,%d,%d,%d\n",atk.ct1.c1,atk.ct1.c2,atk.ct1.c3,atk.ct1.c4,atk.ct1.v);
				kemenc_Attack(ct,atk.ct1, k, i, task_list);
				res_1 = SCA_oracle(ct, sk, m);
				kemenc_Attack(ct,atk.ct2, k, i, task_list);
				res_2 = SCA_oracle(ct, sk, m);
				if (res_1 == atk.ct1_res && res_2 == atk.ct2_res)
				{
					int value = sksv1_recovered[i][task_list[k*4]];
					cofc[i][task_list[k*4]].confidence[value+3] += CC1;
					value = sksv1_recovered[i][task_list[k*4+1]];
					cofc[i][task_list[k*4+1]].confidence[value+3] += CC1;
					value = sksv1_recovered[i][task_list[k*4+2]];
					cofc[i][task_list[k*4+2]].confidence[value+3] += CC1;
					value = sksv1_recovered[i][task_list[k*4+3]];
					cofc[i][task_list[k*4+3]].confidence[value+3] += CC1;
				}
				else
				{
					err_cof_i[err_cof_cnt] = i;
					err_cof_i[err_cof_cnt+1] = i;
					err_cof_i[err_cof_cnt+2] = i;
					err_cof_i[err_cof_cnt+3] = i;

					err_cof_k[err_cof_cnt] = task_list[k*4];
					err_cof_k[err_cof_cnt+1] = task_list[k*4+1];
					err_cof_k[err_cof_cnt+2] = task_list[k*4+2];
					err_cof_k[err_cof_cnt+3] = task_list[k*4+3];
					err_cof_cnt+=4;
					// printf("k = %d, block = %d, error!\n",i,k);
					// printf("err in %d,%d,%d,%d\n",task_list[k*4],task_list[k*4+1],task_list[k*4+2],task_list[k*4+3]);
					// err_block[i] = k;
				}
				query_check += 2;
			}
		}

		save[2] = query_check;
		
		for(int j = 0; j < err_cof_cnt; j++) {
			int i = err_cof_i[j];
			int k = err_cof_k[j];
			if(cofc[i][k].isok)
				continue;
			if(cofc[i][k].most_confidence > getli(round))
				continue;
			memset(b,0,sizeof(b));
			int rev=0;
			if(k==0) b[i][k]=4;
			else b[i][SABER_N-k]=1024-4;
			POLVECp2BS(ct,b);
			cm[0]=16;
			POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);

			rev=SCA_oracle(ct,sk,m);
			query_reclt++;
			if(rev==1){
				if(k==0) b[i][k]=13;
				else b[i][SABER_N-k]=1024-13;
				POLVECp2BS(ct,b);
				cm[0]=15;
				POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);
				rev=SCA_oracle(ct,sk,m);
				query_reclt++;
				if(rev==0) sksv_recovered[i][k]=0;
				else{
					if(k==0) b[i][k]=12;
					else b[i][SABER_N-k]=1024-12;
					POLVECp2BS(ct,b);
					cm[0]=15;
					POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);
					rev=SCA_oracle(ct,sk,m);
					query_reclt++;
					if(rev==0) sksv_recovered[i][k]=8192-1;
					else{
						if(k==0) b[i][k]=6;
						else b[i][SABER_N-k]=1024-6;
						POLVECp2BS(ct,b);
						cm[0]=15;
						POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);
						rev=SCA_oracle(ct,sk,m);
						query_reclt++;
						if(rev==0) sksv_recovered[i][k]=8192-2;
						else sksv_recovered[i][k]=8192-3;
					}
				}
			}
			else{
				if(k==0) b[i][k]=3;
				else b[i][SABER_N-k]=1024-3;
				POLVECp2BS(ct,b);
				cm[0]=16;
				POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);
				rev=SCA_oracle(ct,sk,m);
				query_reclt++;
				if(rev==1) sksv_recovered[i][k]=1;
				else{
					if(k==0) b[i][k]=7;
					else b[i][SABER_N-k]=1024-7;
					POLVECp2BS(ct,b);
					cm[0]=17;
					POLT2BS(ct + SABER_POLYVECCOMPRESSEDBYTES, cm);
					rev=SCA_oracle(ct,sk,m);
					query_reclt++;
					if(rev==1) sksv_recovered[i][k]=2;
					else sksv_recovered[i][k]=3;
				}
			}
			if(sksv_recovered[i][k]>3) sksv1_recovered[i][k]=sksv_recovered[i][k]-8192;
			else sksv1_recovered[i][k]=sksv_recovered[i][k];
			int value = sksv1_recovered[i][k];
			cofc[i][k].confidence[value+3] += CC2;
		}
		//update
		for(int i=0;i<SABER_L;i++){
			for(int k = 0; k < SABER_N; k++) {
				for(int v=0;v<7;v++)
				{
					if(cofc[i][k].confidence[v] >= cofc[i][k].most_confidence)
					{
						cofc[i][k].most_possible_cof = v;
						cofc[i][k].most_confidence=cofc[i][k].confidence[v];
					}
				}
				if(!cofc[i][k].isok && cofc[i][k].most_confidence > getli(round))
				{
					cofc[i][k].isok = 1;
					already++;
				}	
				sksv1_recovered[i][k] = cofc[i][k].most_possible_cof-3;
			}
		}
		//printf("err_cof_cnt=%d,round=%d,already=%d,erral=%d\n",err_cof_cnt,round,already,erral);
		err_cof_cnt=0;
	}

	

    save[3] = query_reclt;
    checks = 0;
    for(int i = 0; i < SABER_L; i++) {
        for(int j = 0; j < SABER_N; j++) {
            if(sksv1_recovered[i][j] != sksv1[i][j]) {
                checks++;
                //printf("error s in s[%d][%d] ", i, j);
            }
        }
    }
    save[4] = checks;

    save[5] = query+query_check+query_reclt;

}


int
main(int argc, char * argv[])
{
    init_attackinfo();
    FILE * fp = fopen("result_our_method.csv","w");
    fprintf(fp,"recovery_query,err_without_check,check_query,recollect_query,err_with_check,total_query\n");
    for(int i=1;i<=EXPERIMENT_TIMES;i++)
    {
        int tmp[6];
        saber_Attack(i,tmp);
        fprintf(fp,"%d,%d,%d,%d,%d,%d\n",tmp[0],tmp[1],tmp[2],tmp[3],tmp[4],tmp[5]);
        if(i % 1000 == 0)
            printf("done %d tests...\n",i);
    }
    fclose(fp);
    return 0;

}