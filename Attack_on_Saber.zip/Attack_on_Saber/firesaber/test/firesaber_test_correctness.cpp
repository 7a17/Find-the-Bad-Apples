#include <iostream>

#define SABER_MU 6
#define SABER_ET 6
#define SABER_EQ 13
#define SABER_EP 10
#define SABER_N 256

#define h1 (1 << (SABER_EQ - SABER_EP - 1))
#define h2 ((1 << (SABER_EP - 2)) - (1 << (SABER_EP - SABER_ET - 1)) + (1 << (SABER_EQ - SABER_EP - 1)))

typedef struct _ctinfo
{
	int b1;
	int b2;
	int b3;
	int b4;
	int cm;
}ct_info;

typedef struct _attackinfo{
	int aval;
	ct_info ct1;
	int ct1_res;
	ct_info ct2;
	int ct2_res;
}attack_info;


int cof_firesaber[7] = {-3,-2,-1,0,1,2,3};

static int POS4(int a,int b,int c,int d){
	return a + b*7 + c*49 + d * 49*7;
}

attack_info gl_info[49*49];

void init_attackinfo()
{
	FILE * fp = fopen("more_data2_firesaber.txt","r");
	if(fp == NULL){
		printf("err read file!");
		exit(0);
	}
	for(int i=0;i<49*49;i++){
		int unused;
		fscanf(fp,"%d,%d,%d,%d,%d,",&unused,&unused,&unused,&unused,&gl_info[i].aval);
		fscanf(fp,"%d,%d,%d,%d,%d,%d,",&gl_info[i].ct1.b1,&gl_info[i].ct1.b2,&gl_info[i].ct1.b3,&gl_info[i].ct1.b4,&gl_info[i].ct1.cm,&gl_info[i].ct1_res);
		fscanf(fp,"%d,%d,%d,%d,%d,%d\n",&gl_info[i].ct2.b1,&gl_info[i].ct2.b2,&gl_info[i].ct2.b3,&gl_info[i].ct2.b4,&gl_info[i].ct2.cm,&gl_info[i].ct2_res);
	}
}

int main(int argc, char *argv[]) {
	int aval_cnt = 0,checked_cnt = 0;
	init_attackinfo();
    int tmp=0;
	for(int r=0;r<49*49;r++){
		if(gl_info[r].aval == 0){
			//printf("i = %d, not available, ignore...\n",r);
			continue;
		}
		aval_cnt++;
		int tmp_result1[7*7*7*7],tmp_result2[7*7*7*7];
		int cm1,c11,c21,c31,c41,cm2,c12,c22,c32,c42;
		c11=gl_info[r].ct1.b1,c21=gl_info[r].ct1.b2,c31=gl_info[r].ct1.b3,c41=gl_info[r].ct1.b4,cm1=gl_info[r].ct1.cm;
		c12=gl_info[r].ct2.b1,c22=gl_info[r].ct2.b2,c32=gl_info[r].ct2.b3,c42=gl_info[r].ct2.b4,cm2=gl_info[r].ct2.cm;
		
        /*
		int choose_u11 = (int)(KYBER_Q*c11/1024.0 + 0.5);
		int choose_u21 = (int)(KYBER_Q*c21/1024.0 + 0.5);
		int choose_u31 = (int)(KYBER_Q*c31/1024.0 + 0.5);
		int choose_u41 = (int)(KYBER_Q*c41/1024.0 + 0.5);
		
		int choose_u12 = (int)(KYBER_Q*c12/1024.0 + 0.5);
		int choose_u22 = (int)(KYBER_Q*c22/1024.0 + 0.5);
		int choose_u32 = (int)(KYBER_Q*c32/1024.0 + 0.5);
		int choose_u42 = (int)(KYBER_Q*c42/1024.0 + 0.5);
        */
		
		for(int i1=0;i1<7;i1++){
			for(int i2=0;i2<7;i2++){
				for(int i3=0;i3<7;i3++){
					for(int i4=0;i4<7;i4++){
						tmp=c11*cof_firesaber[i1]+c21*cof_firesaber[i2]+c31*cof_firesaber[i3]+c41*cof_firesaber[i4] + h2 - (cm1 << (SABER_EP - SABER_ET));
                        while(tmp>=1024){
                            tmp-=1024;
                        }
						while(tmp<0){
							tmp+=1024;
						}
						tmp_result1[POS4(i1,i2,i3,i4)]=tmp>>(SABER_EP-1);
					}
				}
			}
		}
		
		for(int i1=0;i1<7;i1++){
			for(int i2=0;i2<7;i2++){
				for(int i3=0;i3<7;i3++){
					for(int i4=0;i4<7;i4++){
						tmp=c12*cof_firesaber[i1]+c22*cof_firesaber[i2]+c32*cof_firesaber[i3]+c42*cof_firesaber[i4] + h2 - (cm2 << (SABER_EP - SABER_ET));
                        while(tmp>=1024){
                            tmp-=1024;
                        }
						while(tmp<0){
							tmp+=1024;
						}
						tmp_result2[POS4(i1,i2,i3,i4)]=tmp>>(SABER_EP-1);
					}
				}
			}
		}
		
		int cnt00=0,cnt01=0,cnt10=0,cnt11=0;
		
		for(int i=0;i<7*7*7*7;i++){
			if(tmp_result1[i] == 0 && tmp_result2[i] == 0){
				cnt00++;
			}
			else if(tmp_result1[i] == 0 && tmp_result2[i] == 1){
				cnt01++;
			}
			else if(tmp_result1[i] == 1 && tmp_result2[i] == 0){
				cnt10++;
			}
			else if(tmp_result1[i] == 1 && tmp_result2[i] == 1){
				cnt11++;
			}
		}
		int a,b,c,d;
		d = r%7;
		c = (r%49)/7;
		b = r/49%7;
		a = r/49/7;
		printf("cnt00 = %4d, cnt01 = %4d, cnt10 = %4d, cnt11 = %4d\n",cnt00,cnt01,cnt10,cnt11);
		if(cnt00==1 && gl_info[r].ct1_res == 0 && gl_info[r].ct2_res == 0){
			for(int i=0;i<7*7*7*7;i++){
				if(tmp_result1[i] == 0 && tmp_result2[i] == 0){
					if(i%7 == a && (i%49)/7 == b && i/49%7 == c && i/49/7 == d){
						//printf("we can indentify i = %d. i.e. (%d,%d,%d,%d)\n",i,a,b,c,d);
						checked_cnt++;
						break;
					}
				}
			}
		}
		if(cnt01==1 && gl_info[r].ct1_res == 0 && gl_info[r].ct2_res == 1){
			for(int i=0;i<7*7*7*7;i++){
				if(tmp_result1[i] == 0 && tmp_result2[i] == 1){
					if(i%7 == a && (i%49)/7 == b && i/49%7 == c && i/49/7 == d){
						//printf("we can indentify i = %d. i.e. (%d,%d,%d,%d)\n",i,a,b,c,d);
						checked_cnt++;
						break;
					}
				}
			}
		}
		
		if(cnt10==1 && gl_info[r].ct1_res == 1 && gl_info[r].ct2_res == 0){
			for(int i=0;i<7*7*7*7;i++){
				if(tmp_result1[i] == 1 && tmp_result2[i] == 0){
					if(i%7 == a && (i%49)/7 == b && i/49%7 == c && i/49/7 == d){
						//printf("we can indentify i = %d. i.e. (%d,%d,%d,%d)\n",i,a,b,c,d);
						checked_cnt++;
						break;
					}
				}
			}
		}
		if(cnt11==1 && gl_info[r].ct1_res == 1 && gl_info[r].ct2_res == 1){
			for(int i=0;i<7*7*7*7;i++){
				if(tmp_result1[i] == 1 && tmp_result2[i] == 1){
					if(i%7 == a && (i%49)/7 == b && i/49%7 == c && i/49/7 == d){
						//printf("we can indentify i = %d. i.e. (%d,%d,%d,%d)\n",i,a,b,c,d);
						checked_cnt++;
						break;
					}
				}
			}
		}
		
	}
	printf("aval = %d, checked_success = %d.\n",aval_cnt,checked_cnt);
}

